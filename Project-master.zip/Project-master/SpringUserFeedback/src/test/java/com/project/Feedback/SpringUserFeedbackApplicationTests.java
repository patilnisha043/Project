package com.project.Feedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringUserFeedbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
